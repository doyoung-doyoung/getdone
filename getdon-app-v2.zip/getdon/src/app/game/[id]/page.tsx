'use client'

import { useState, useEffect, useRef } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { Round, Member, GameType } from '@/types'
import Link from 'next/link'

// ========== GAME: DRAW ==========
function DrawGame({ members, onWinner }: { members: Member[], onWinner: (m: Member) => void }) {
  const [spinning, setSpinning] = useState(false)
  const [picked, setPicked] = useState<number | null>(null)
  const [angle, setAngle] = useState(0)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const eligible = members.filter(m => !m.has_won)

  useEffect(() => { drawWheel(angle) }, [angle, eligible])

  function drawWheel(rot: number) {
    const canvas = canvasRef.current
    if (!canvas || eligible.length === 0) return
    const ctx = canvas.getContext('2d')!
    const cx = canvas.width / 2, cy = canvas.height / 2, r = cx - 10
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    const colors = ['#C9A84C','#8B6914','#F0D080','#2E3560','#1A1F3A','#252B4A','#C9A84C','#8B6914']
    const slice = (2 * Math.PI) / eligible.length

    eligible.forEach((m, i) => {
      const start = rot + i * slice
      const end = start + slice
      ctx.beginPath()
      ctx.moveTo(cx, cy)
      ctx.arc(cx, cy, r, start, end)
      ctx.fillStyle = colors[i % colors.length]
      ctx.fill()
      ctx.strokeStyle = '#1A1F3A'
      ctx.lineWidth = 2
      ctx.stroke()

      ctx.save()
      ctx.translate(cx, cy)
      ctx.rotate(start + slice / 2)
      ctx.textAlign = 'right'
      ctx.fillStyle = '#FDF8EF'
      ctx.font = `bold ${Math.max(10, 14 - eligible.length)}px Noto Sans KR, sans-serif`
      ctx.fillText(m.name, r - 10, 5)
      ctx.restore()
    })

    // Center circle
    ctx.beginPath()
    ctx.arc(cx, cy, 20, 0, 2 * Math.PI)
    ctx.fillStyle = '#1A1F3A'
    ctx.fill()
    ctx.strokeStyle = '#C9A84C'
    ctx.lineWidth = 2
    ctx.stroke()

    // Pointer
    ctx.beginPath()
    ctx.moveTo(cx + r - 5, cy - 10)
    ctx.lineTo(cx + r + 15, cy)
    ctx.lineTo(cx + r - 5, cy + 10)
    ctx.fillStyle = '#ff4444'
    ctx.fill()
  }

  function spin() {
    if (spinning || eligible.length === 0) return
    setSpinning(true)
    setPicked(null)
    const extraSpins = 5 + Math.random() * 5
    const targetIdx = Math.floor(Math.random() * eligible.length)
    const slice = (2 * Math.PI) / eligible.length
    const targetAngle = -(targetIdx * slice + slice / 2) + Math.PI / 2
    const total = extraSpins * 2 * Math.PI + targetAngle
    let current = angle
    const duration = 4000
    const start = performance.now()

    function animate(now: number) {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 4)
      current = angle + total * eased
      setAngle(current)
      drawWheel(current)
      if (progress < 1) {
        requestAnimationFrame(animate)
      } else {
        setSpinning(false)
        setPicked(targetIdx)
        onWinner(eligible[targetIdx])
      }
    }
    requestAnimationFrame(animate)
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="relative">
        <canvas ref={canvasRef} width={280} height={280} className="rounded-full" />
      </div>
      {picked !== null && (
        <div className="text-center animate-bounce-in">
          <div className="text-3xl">🎉</div>
          <div className="text-xl font-black mt-1" style={{ color: 'var(--gold)' }}>{eligible[picked]?.name}</div>
        </div>
      )}
      <button onClick={spin} disabled={spinning || eligible.length === 0} className="px-12 py-4 rounded-xl font-black text-xl btn-gold disabled:opacity-50">
        {spinning ? '돌아가는 중...' : '🎡 돌리기!'}
      </button>
    </div>
  )
}

// ========== GAME: BUTTON ==========
function ButtonGame({ members, onWinner }: { members: Member[], onWinner: (m: Member) => void }) {
  const eligible = members.filter(m => !m.has_won)
  const [pressed, setPressed] = useState<Set<string>>(new Set())
  const [winner, setWinner] = useState<Member | null>(null)
  const [phase, setPhase] = useState<'waiting' | 'countdown' | 'result'>('waiting')
  const [countdown, setCountdown] = useState(3)
  const [winnerIdx, setWinnerIdx] = useState<number | null>(null)

  function startGame() {
    setPressed(new Set())
    setWinner(null)
    setWinnerIdx(null)
    setPhase('countdown')
    let c = 3
    setCountdown(c)
    const interval = setInterval(() => {
      c--
      setCountdown(c)
      if (c <= 0) {
        clearInterval(interval)
        setPhase('waiting')
        // Randomly pick among pressed or all if none
      }
    }, 1000)
  }

  function pressButton(member: Member) {
    if (phase !== 'waiting' || winner) return
    const newPressed = new Set(pressed)
    newPressed.add(member.id)
    setPressed(newPressed)
    
    // Last one triggers win
    if (newPressed.size >= eligible.length) {
      const idx = Math.floor(Math.random() * eligible.length)
      setWinnerIdx(idx)
      setWinner(eligible[idx])
      onWinner(eligible[idx])
    }
  }

  return (
    <div className="space-y-6">
      {phase === 'countdown' && (
        <div className="text-center">
          <div className="text-8xl font-black" style={{ color: 'var(--gold)' }}>{countdown}</div>
          <div style={{ color: 'rgba(253,248,239,0.5)' }}>버튼을 누를 준비!</div>
        </div>
      )}

      {!winner && (
        <div className="text-center text-sm mb-2" style={{ color: 'rgba(253,248,239,0.5)' }}>
          모든 사람이 버튼을 누르면 당첨자가 결정됩니다 ({pressed.size}/{eligible.length})
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        {eligible.map((m, i) => {
          const isPressed = pressed.has(m.id)
          const isWinner = winner?.id === m.id
          return (
            <button
              key={m.id}
              onClick={() => pressButton(m)}
              disabled={isPressed || !!winner}
              className="py-6 px-4 rounded-2xl font-black text-lg transition-all"
              style={{
                background: isWinner 
                  ? 'linear-gradient(135deg, var(--gold-light), var(--gold))' 
                  : isPressed 
                  ? 'rgba(76,175,80,0.3)'
                  : 'var(--navy-mid)',
                color: isWinner ? 'var(--navy)' : 'var(--cream)',
                border: isWinner ? '2px solid var(--gold)' : '1px solid rgba(255,255,255,0.1)',
                transform: isWinner ? 'scale(1.05)' : isPressed ? 'scale(0.95)' : 'scale(1)',
                boxShadow: isWinner ? '0 0 30px rgba(201,168,76,0.5)' : 'none',
              }}
            >
              {isWinner ? '🏆' : isPressed ? '✅' : '🔴'}<br />
              {m.name}
            </button>
          )
        })}
      </div>

      {winner && (
        <div className="text-center animate-bounce-in card p-6">
          <div className="text-4xl">🎊</div>
          <div className="text-2xl font-black mt-2" style={{ color: 'var(--gold)' }}>{winner.name} 당첨!</div>
        </div>
      )}

      {!winner && (
        <button onClick={startGame} className="w-full py-3 rounded-xl font-bold btn-gold">
          🎮 게임 시작
        </button>
      )}
    </div>
  )
}

// ========== GAME: DICE ==========
function DiceGame({ members, onWinner }: { members: Member[], onWinner: (m: Member) => void }) {
  const eligible = members.filter(m => !m.has_won)
  const [results, setResults] = useState<Record<string, number>>({})
  const [rolling, setRolling] = useState<string | null>(null)
  const [winner, setWinner] = useState<Member | null>(null)
  const [currentIdx, setCurrentIdx] = useState(0)

  const diceFaces: Record<number, string> = {
    1: '⚀', 2: '⚁', 3: '⚂', 4: '⚃', 5: '⚄', 6: '⚅'
  }

  function rollDice(member: Member) {
    if (rolling || results[member.id] !== undefined || winner) return
    setRolling(member.id)
    let count = 0
    const interval = setInterval(() => {
      setResults(prev => ({ ...prev, [member.id]: Math.floor(Math.random() * 6) + 1 }))
      count++
      if (count > 10) {
        clearInterval(interval)
        const finalVal = Math.floor(Math.random() * 6) + 1
        setResults(prev => {
          const next = { ...prev, [member.id]: finalVal }
          if (Object.keys(next).length === eligible.length) {
            const maxVal = Math.max(...Object.values(next))
            const winnerId = Object.entries(next).find(([_, v]) => v === maxVal)?.[0]
            const w = eligible.find(m => m.id === winnerId)
            if (w) { setWinner(w); onWinner(w) }
          }
          return next
        })
        setRolling(null)
        setCurrentIdx(i => i + 1)
      }
    }, 80)
  }

  function rollAll() {
    eligible.forEach((m, i) => {
      setTimeout(() => rollDice(m), i * 800)
    })
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3">
        {eligible.map(m => {
          const val = results[m.id]
          const isWinner = winner?.id === m.id
          const isRolling = rolling === m.id
          return (
            <div key={m.id} className="card p-4 text-center" style={{
              borderColor: isWinner ? 'var(--gold)' : undefined,
              boxShadow: isWinner ? '0 0 20px rgba(201,168,76,0.4)' : undefined,
            }}>
              <div className="text-5xl" style={{ 
                transition: 'transform 0.1s',
                transform: isRolling ? 'rotate(180deg)' : 'none'
              }}>
                {val ? diceFaces[val] : '🎲'}
              </div>
              <div className="font-bold mt-2">{m.name}</div>
              <div className="text-2xl font-black" style={{ color: 'var(--gold)' }}>
                {val || '-'}
              </div>
              {isWinner && <div className="text-xs mt-1" style={{ color: 'var(--gold)' }}>🏆 최고점!</div>}
            </div>
          )
        })}
      </div>

      {winner && (
        <div className="text-center animate-bounce-in card p-6">
          <div className="text-4xl">🎲</div>
          <div className="text-2xl font-black mt-2" style={{ color: 'var(--gold)' }}>{winner.name} 당첨!</div>
          <div className="text-sm mt-1" style={{ color: 'rgba(253,248,239,0.5)' }}>최고 점수로 당첨되었습니다!</div>
        </div>
      )}

      {!winner && (
        <button onClick={rollAll} disabled={!!rolling} className="w-full py-4 rounded-xl font-black text-xl btn-gold disabled:opacity-50">
          🎲 모두 주사위 굴리기!
        </button>
      )}
    </div>
  )
}

// ========== GAME: LADDER ==========
function LadderGame({ members, onWinner }: { members: Member[], onWinner: (m: Member) => void }) {
  const eligible = members.filter(m => !m.has_won)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [revealed, setRevealed] = useState(false)
  const [winner, setWinner] = useState<Member | null>(null)
  const [paths, setPaths] = useState<number[]>([]) // paths[i] = destination index for member i
  const [selectedPath, setSelectedPath] = useState<number | null>(null)
  const [runningIdx, setRunningIdx] = useState<number | null>(null)

  const n = eligible.length
  const cols = n
  const rows = Math.max(8, n * 2)

  // Generate ladder structure
  const [bridges, setBridges] = useState<{row: number; col: number}[]>([])

  useEffect(() => {
    if (eligible.length < 2) return
    const newBridges: {row: number; col: number}[] = []
    for (let row = 1; row < rows - 1; row++) {
      for (let col = 0; col < cols - 1; col++) {
        const hasLeft = col > 0 && newBridges.some(b => b.row === row && b.col === col - 1)
        if (!hasLeft && Math.random() > 0.65) {
          newBridges.push({ row, col })
          col++ // skip next column
        }
      }
    }
    setBridges(newBridges)
    
    // Calculate paths
    const result = eligible.map((_, startCol) => {
      let col = startCol
      for (let row = 0; row < rows; row++) {
        const rightBridge = newBridges.find(b => b.row === row && b.col === col)
        const leftBridge = newBridges.find(b => b.row === row && b.col === col - 1)
        if (rightBridge) col++
        else if (leftBridge) col--
      }
      return col
    })
    setPaths(result)
  }, [eligible.length])

  useEffect(() => {
    drawLadder()
  }, [bridges, revealed, selectedPath, runningIdx, eligible])

  function drawLadder() {
    const canvas = canvasRef.current
    if (!canvas || eligible.length < 2) return
    const ctx = canvas.getContext('2d')!
    const W = canvas.width, H = canvas.height
    ctx.clearRect(0, 0, W, H)

    const colSpacing = W / (cols + 1)
    const rowSpacing = (H - 60) / (rows + 1)
    const colX = (col: number) => colSpacing * (col + 1)
    const rowY = (row: number) => 30 + rowSpacing * (row + 1)

    // Draw vertical lines
    for (let col = 0; col < cols; col++) {
      ctx.beginPath()
      ctx.moveTo(colX(col), rowY(0))
      ctx.lineTo(colX(col), rowY(rows - 1))
      ctx.strokeStyle = 'rgba(201,168,76,0.4)'
      ctx.lineWidth = 2
      ctx.stroke()
    }

    // Draw bridges
    bridges.forEach(b => {
      ctx.beginPath()
      ctx.moveTo(colX(b.col), rowY(b.row))
      ctx.lineTo(colX(b.col + 1), rowY(b.row))
      ctx.strokeStyle = 'rgba(201,168,76,0.7)'
      ctx.lineWidth = 3
      ctx.stroke()
    })

    // Top labels (names)
    eligible.forEach((m, col) => {
      ctx.fillStyle = selectedPath === col ? 'var(--gold)' : 'rgba(253,248,239,0.8)'
      ctx.font = `bold ${Math.max(9, 12 - cols)}px Noto Sans KR, sans-serif`
      ctx.textAlign = 'center'
      ctx.fillText(m.name.slice(0, 3), colX(col), 20)
    })

    // Bottom results
    if (revealed && paths.length > 0) {
      const wonIdx = paths.indexOf(paths.findIndex((p, i) => eligible[p]?.id === winner?.id))
      eligible.forEach((_, col) => {
        const dest = paths[col]
        const destMem = eligible[dest]
        const isWinner = destMem?.id === winner?.id
        ctx.fillStyle = isWinner ? '#C9A84C' : 'rgba(253,248,239,0.5)'
        ctx.font = `bold ${Math.max(9, 12 - cols)}px Noto Sans KR, sans-serif`
        ctx.textAlign = 'center'
        ctx.fillText(isWinner ? '🏆' : '❌', colX(dest), H - 8)
      })
    }
  }

  function startLadder() {
    setRevealed(true)
    // Winner is the member whose path leads to "slot 0" (first position)
    const winnerDestCol = 0
    const winnerStartIdx = paths.indexOf(winnerDestCol)
    if (winnerStartIdx >= 0 && eligible[winnerStartIdx]) {
      const w = eligible[winnerStartIdx]
      setTimeout(() => {
        setWinner(w)
        onWinner(w)
      }, 1000)
    }
  }

  return (
    <div className="space-y-4">
      <div className="card p-2" style={{ background: 'var(--navy-mid)' }}>
        <canvas ref={canvasRef} width={320} height={360} className="w-full" />
      </div>

      {winner && revealed && (
        <div className="text-center animate-bounce-in card p-6">
          <div className="text-4xl">🪜</div>
          <div className="text-2xl font-black mt-2" style={{ color: 'var(--gold)' }}>{winner.name} 당첨!</div>
        </div>
      )}

      {!revealed && (
        <button onClick={startLadder} className="w-full py-4 rounded-xl font-black text-xl btn-gold">
          🪜 사다리 공개!
        </button>
      )}
    </div>
  )
}

// ========== MAIN GAME PAGE ==========
export default function GamePage() {
  const { id } = useParams()
  const router = useRouter()
  const [round, setRound] = useState<Round | null>(null)
  const [members, setMembers] = useState<Member[]>([])
  const [gameType, setGameType] = useState<GameType | null>(null)
  const [winner, setWinner] = useState<Member | null>(null)
  const [confirmed, setConfirmed] = useState(false)
  const [loading, setLoading] = useState(true)
  const [confetti, setConfetti] = useState(false)

  useEffect(() => {
    fetchData()
  }, [id])

  async function fetchData() {
    const { data: r } = await supabase.from('rounds').select('*').eq('id', id).single()
    if (r) setRound(r as Round)
    const { data: m } = await supabase.from('members').select('*').eq('round_id', id)
    setMembers((m as Member[]) || [])
    setLoading(false)
  }

  async function handleWinner(member: Member) {
    setWinner(member)
    setConfetti(true)
    setTimeout(() => setConfetti(false), 4000)
  }

  async function confirmWinner() {
    if (!winner || !round || !gameType) return
    await supabase.from('rounds').update({
      winner_id: winner.id,
      winner_name: winner.name,
      game_type: gameType,
      status: 'game_played',
    }).eq('id', round.id)
    await supabase.from('members').update({ has_won: true }).eq('id', winner.id)
    setConfirmed(true)
    setTimeout(() => router.push(`/receipt/${round.id}`), 1500)
  }

  const games: { type: GameType; emoji: string; label: string; desc: string }[] = [
    { type: 'draw', emoji: '🎡', label: '룰렛 뽑기', desc: '돌려돌려 룰렛!' },
    { type: 'button', emoji: '🔴', label: '버튼 누르기', desc: '모두가 버튼을 누르면 당첨!' },
    { type: 'dice', emoji: '🎲', label: '주사위 굴리기', desc: '가장 높은 숫자가 당첨!' },
    { type: 'ladder', emoji: '🪜', label: '사다리 타기', desc: '사다리를 타고 내려가면?' },
  ]

  if (loading) return (
    <main className="min-h-screen flex items-center justify-center">
      <div className="text-center" style={{ color: 'var(--gold)' }}>
        <div className="text-4xl mb-3">⏳</div>
        <p>불러오는 중...</p>
      </div>
    </main>
  )

  if (!round) return (
    <main className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <p style={{ color: 'rgba(253,248,239,0.5)' }}>판을 찾을 수 없습니다</p>
        <Link href="/admin" className="block mt-4 btn-gold px-6 py-2 rounded-xl font-bold">관리자로 돌아가기</Link>
      </div>
    </main>
  )

  const eligible = members.filter(m => !m.has_won)

  return (
    <main className="min-h-screen p-4 md:p-8">
      {/* Confetti */}
      {confetti && (
        <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
          {Array.from({ length: 30 }).map((_, i) => (
            <div key={i} style={{
              position: 'absolute',
              left: `${Math.random() * 100}%`,
              top: '-20px',
              width: '10px',
              height: '10px',
              background: ['#C9A84C','#F0D080','#8B6914','#ff6b6b','#4a9eff'][i % 5],
              borderRadius: Math.random() > 0.5 ? '50%' : '0',
              animation: `confetti-fall ${2 + Math.random() * 2}s linear ${Math.random() * 2}s forwards`,
            }} />
          ))}
        </div>
      )}

      <div className="max-w-lg mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-black" style={{ color: 'var(--gold)' }}>🎮 게임 룸</h1>
            <p className="text-sm" style={{ color: 'rgba(253,248,239,0.5)' }}>{round.round_number}판 · {round.month}</p>
          </div>
          <Link href="/admin" className="text-sm px-3 py-1 rounded-lg" style={{ background: 'rgba(255,255,255,0.1)' }}>← 관리자</Link>
        </div>

        {/* Round info */}
        <div className="card p-4 flex gap-4">
          <div className="text-center flex-1">
            <div className="text-2xl font-black" style={{ color: 'var(--gold)' }}>{eligible.length}</div>
            <div className="text-xs" style={{ color: 'rgba(253,248,239,0.5)' }}>참가 가능 인원</div>
          </div>
          <div className="text-center flex-1">
            <div className="text-2xl font-black" style={{ color: 'var(--gold)' }}>{round.amount.toLocaleString()}</div>
            <div className="text-xs" style={{ color: 'rgba(253,248,239,0.5)' }}>원</div>
          </div>
          <div className="text-center flex-1">
            <div className="text-2xl font-black" style={{ color: 'var(--gold)' }}>{members.filter(m => m.has_won).length}</div>
            <div className="text-xs" style={{ color: 'rgba(253,248,239,0.5)' }}>이미 받은 사람</div>
          </div>
        </div>

        {eligible.length === 0 && (
          <div className="card p-6 text-center" style={{ color: 'rgba(253,248,239,0.5)' }}>
            <div className="text-4xl mb-2">🎊</div>
            <p>모든 참가자가 이미 당첨되었습니다!</p>
          </div>
        )}

        {/* Game selection */}
        {!gameType && eligible.length > 0 && (
          <div className="space-y-3">
            <h2 className="font-bold text-lg" style={{ color: 'var(--gold)' }}>게임 선택</h2>
            <div className="grid grid-cols-2 gap-3">
              {games.map(g => (
                <button key={g.type} onClick={() => setGameType(g.type)}
                  className="card p-5 text-left hover:border-yellow-500 transition-all">
                  <div className="text-3xl">{g.emoji}</div>
                  <div className="font-bold mt-2">{g.label}</div>
                  <div className="text-xs mt-1" style={{ color: 'rgba(253,248,239,0.5)' }}>{g.desc}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Active game */}
        {gameType && eligible.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-lg" style={{ color: 'var(--gold)' }}>
                {games.find(g => g.type === gameType)?.emoji} {games.find(g => g.type === gameType)?.label}
              </h2>
              {!winner && (
                <button onClick={() => setGameType(null)} className="text-sm opacity-50">다른 게임</button>
              )}
            </div>

            {gameType === 'draw' && <DrawGame members={members} onWinner={handleWinner} />}
            {gameType === 'button' && <ButtonGame members={members} onWinner={handleWinner} />}
            {gameType === 'dice' && <DiceGame members={members} onWinner={handleWinner} />}
            {gameType === 'ladder' && <LadderGame members={members} onWinner={handleWinner} />}
          </div>
        )}

        {/* Winner confirmation */}
        {winner && !confirmed && (
          <div className="card card-glow p-6 text-center space-y-4">
            <div className="text-5xl">🏆</div>
            <div>
              <div className="text-sm" style={{ color: 'rgba(253,248,239,0.5)' }}>당첨자</div>
              <div className="text-3xl font-black" style={{ color: 'var(--gold)' }}>{winner.name}</div>
            </div>
            <div className="text-2xl font-bold" style={{ color: 'var(--gold-light)' }}>
              💰 {round.amount.toLocaleString()}원
            </div>
            <div className="flex gap-3">
              <button onClick={confirmWinner} className="flex-1 py-3 rounded-xl font-bold btn-gold">
                ✅ 당첨 확정!
              </button>
              <button onClick={() => { setWinner(null); setGameType(null) }} className="px-4 py-3 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.1)' }}>
                다시
              </button>
            </div>
          </div>
        )}

        {confirmed && (
          <div className="card p-6 text-center">
            <div className="text-4xl">✅</div>
            <p className="mt-2 font-bold" style={{ color: '#4caf50' }}>당첨 확정 완료! 영수증으로 이동합니다...</p>
          </div>
        )}
      </div>
    </main>
  )
}
