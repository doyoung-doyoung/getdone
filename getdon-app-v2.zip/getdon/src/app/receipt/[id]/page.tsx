'use client'

import { useState, useEffect, useRef } from 'react'
import { useParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { Round, Member } from '@/types'
import Link from 'next/link'

const gameLabels: Record<string, string> = {
  draw: '룰렛 뽑기',
  button: '버튼 누르기',
  dice: '주사위 굴리기',
  ladder: '사다리 타기',
}

export default function ReceiptPage() {
  const { id } = useParams()
  const [round, setRound] = useState<Round | null>(null)
  const [members, setMembers] = useState<Member[]>([])
  const [winner, setWinner] = useState<Member | null>(null)
  const [loading, setLoading] = useState(true)
  const receiptRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetchData()
  }, [id])

  async function fetchData() {
    const { data: r } = await supabase.from('rounds').select('*').eq('id', id).single()
    if (r) {
      setRound(r as Round)
      const { data: m } = await supabase.from('members').select('*').eq('round_id', id)
      const mems = (m as Member[]) || []
      setMembers(mems)
      if (r.winner_id) {
        const w = mems.find(mem => mem.id === r.winner_id)
        if (w) setWinner(w)
      }
    }
    setLoading(false)
  }

  async function downloadPDF() {
    const jsPDF = (await import('jspdf')).default
    const html2canvas = (await import('html2canvas')).default

    const element = receiptRef.current
    if (!element) return

    const canvas = await html2canvas(element, {
      scale: 2,
      backgroundColor: '#1A1F3A',
      useCORS: true,
    })

    const imgData = canvas.toDataURL('image/png')
    const pdf = new jsPDF('p', 'mm', 'a5')
    const pdfW = pdf.internal.pageSize.getWidth()
    const pdfH = (canvas.height * pdfW) / canvas.width

    pdf.addImage(imgData, 'PNG', 0, 0, pdfW, pdfH)
    pdf.save(`겟돈-${round?.round_number}판-영수증-${winner?.name}.pdf`)
  }

  const now = new Date()
  const dateStr = now.toLocaleDateString('ko-KR', { year: 'numeric', month: 'long', day: 'numeric' })
  const timeStr = now.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })

  if (loading) return (
    <main className="min-h-screen flex items-center justify-center">
      <p style={{ color: 'var(--gold)' }}>불러오는 중...</p>
    </main>
  )

  if (!round || !winner) return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="text-center space-y-4">
        <p style={{ color: 'rgba(253,248,239,0.5)' }}>영수증 정보를 찾을 수 없습니다</p>
        <Link href="/admin" className="block btn-gold px-6 py-2 rounded-xl font-bold text-center">관리자로 이동</Link>
      </div>
    </main>
  )

  const paidMembers = members.filter(m => m.payment_confirmed)
  const totalPaid = paidMembers.length * round.amount

  return (
    <main className="min-h-screen p-4 md:p-8">
      <div className="max-w-sm mx-auto space-y-6">
        {/* Action buttons */}
        <div className="flex gap-3 items-center">
          <Link href="/admin" className="text-sm px-3 py-1 rounded-lg" style={{ background: 'rgba(255,255,255,0.1)' }}>← 관리자</Link>
          <div className="flex-1" />
          <button onClick={downloadPDF} className="px-4 py-2 rounded-xl font-bold text-sm btn-gold flex items-center gap-2">
            📄 PDF 다운로드
          </button>
        </div>

        {/* Receipt */}
        <div ref={receiptRef} style={{
          background: '#1A1F3A',
          borderRadius: '16px',
          padding: '32px 24px',
          border: '1px solid rgba(201,168,76,0.3)',
          fontFamily: "'Noto Sans KR', sans-serif",
        }}>
          {/* Receipt header */}
          <div style={{ textAlign: 'center', marginBottom: '24px' }}>
            <div style={{ fontSize: '40px' }}>💰</div>
            <h1 style={{ fontSize: '28px', fontWeight: 900, color: '#C9A84C', margin: '8px 0 4px' }}>겟돈</h1>
            <p style={{ fontSize: '12px', color: 'rgba(253,248,239,0.4)', letterSpacing: '2px' }}>계모임 당첨 영수증</p>
          </div>

          {/* Divider */}
          <div style={{ borderTop: '1px dashed rgba(201,168,76,0.4)', margin: '20px 0' }} />

          {/* Winner highlight */}
          <div style={{
            background: 'linear-gradient(135deg, rgba(201,168,76,0.2), rgba(240,208,128,0.1))',
            border: '1px solid rgba(201,168,76,0.4)',
            borderRadius: '12px',
            padding: '20px',
            textAlign: 'center',
            marginBottom: '24px',
          }}>
            <div style={{ fontSize: '32px' }}>🏆</div>
            <div style={{ fontSize: '13px', color: 'rgba(253,248,239,0.5)', marginTop: '8px' }}>당첨자</div>
            <div style={{ fontSize: '32px', fontWeight: 900, color: '#C9A84C', margin: '4px 0' }}>{winner.name}</div>
            <div style={{ fontSize: '24px', fontWeight: 700, color: '#F0D080' }}>
              ₩{round.amount.toLocaleString()}
            </div>
          </div>

          {/* Details */}
          <div style={{ gap: '12px' }}>
            {[
              ['판 번호', `${round.round_number}판`],
              ['모임 월', round.month],
              ['모임 날짜', round.meeting_date || '-'],
              ['게임 방식', gameLabels[round.game_type || ''] || '-'],
              ['총 참가자', `${members.length}명`],
              ['납부 확인', `${paidMembers.length}명`],
              ['총 납부액', `₩${totalPaid.toLocaleString()}`],
            ].map(([label, value]) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                <span style={{ fontSize: '13px', color: 'rgba(253,248,239,0.5)' }}>{label}</span>
                <span style={{ fontSize: '13px', fontWeight: 600, color: 'rgba(253,248,239,0.9)' }}>{value}</span>
              </div>
            ))}
          </div>

          {/* Divider */}
          <div style={{ borderTop: '1px dashed rgba(201,168,76,0.4)', margin: '20px 0' }} />

          {/* Members list */}
          <div>
            <p style={{ fontSize: '11px', color: 'rgba(253,248,239,0.4)', marginBottom: '8px' }}>참가자 명단</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {members.map(m => (
                <span key={m.id} style={{
                  fontSize: '11px',
                  padding: '3px 8px',
                  borderRadius: '20px',
                  background: m.id === winner.id ? 'rgba(201,168,76,0.3)' : 'rgba(255,255,255,0.05)',
                  color: m.id === winner.id ? '#C9A84C' : 'rgba(253,248,239,0.6)',
                  fontWeight: m.id === winner.id ? 700 : 400,
                }}>
                  {m.id === winner.id ? '🏆 ' : ''}{m.name}
                </span>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div style={{ borderTop: '1px dashed rgba(201,168,76,0.4)', margin: '20px 0' }} />

          {/* Timestamp */}
          <div style={{ textAlign: 'center' }}>
            <p style={{ fontSize: '11px', color: 'rgba(253,248,239,0.3)' }}>{dateStr} {timeStr}</p>
            <p style={{ fontSize: '10px', color: 'rgba(253,248,239,0.2)', marginTop: '4px' }}>겟돈 · getdon.vercel.app</p>
          </div>

          {/* Seal */}
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: '16px' }}>
            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              border: '2px solid rgba(201,168,76,0.5)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '24px',
              color: 'rgba(201,168,76,0.5)',
            }}>
              💰
            </div>
          </div>
        </div>

        {/* Share section */}
        <div className="card p-4 space-y-3">
          <h3 className="font-bold text-sm" style={{ color: 'var(--gold)' }}>📤 공유하기</h3>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: '겟돈 당첨!', text: `${winner.name}님이 ${round.month} 겟돈 ${round.round_number}판에서 당첨되었습니다! 💰${round.amount.toLocaleString()}원` })
              } else {
                navigator.clipboard.writeText(`${winner.name}님이 ${round.month} 겟돈 ${round.round_number}판에서 당첨되었습니다! 💰${round.amount.toLocaleString()}원`)
                alert('클립보드에 복사됐습니다!')
              }
            }}
            className="w-full py-3 rounded-xl font-bold text-sm btn-gold"
          >
            📱 카카오톡으로 공유
          </button>
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          <Link href="/admin" className="flex-1 py-3 rounded-xl text-center font-medium text-sm"
            style={{ background: 'rgba(255,255,255,0.1)', color: 'var(--cream)' }}>
            관리자 페이지
          </Link>
          <Link href="/" className="flex-1 py-3 rounded-xl text-center font-medium text-sm"
            style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(253,248,239,0.6)' }}>
            홈으로
          </Link>
        </div>
      </div>
    </main>
  )
}
