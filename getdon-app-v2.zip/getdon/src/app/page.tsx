import Link from 'next/link'

export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="max-w-md w-full text-center space-y-8">
        {/* Logo */}
        <div className="space-y-2">
          <div className="text-7xl">💰</div>
          <h1 className="text-5xl font-black tracking-tight" style={{ color: 'var(--gold)' }}>
            겟돈
          </h1>
          <p className="text-lg" style={{ color: 'rgba(253,248,239,0.6)' }}>
            우리들의 계모임을 스마트하게
          </p>
        </div>

        {/* Main actions */}
        <div className="space-y-4">
          <Link href="/join" className="block w-full py-4 px-6 rounded-2xl text-lg font-bold btn-gold text-center">
            📝 모임 참가하기
          </Link>
          <Link href="/admin" className="block w-full py-4 px-6 rounded-2xl text-lg font-semibold text-center"
            style={{ background: 'rgba(201,168,76,0.15)', border: '1px solid rgba(201,168,76,0.4)', color: 'var(--gold)' }}>
            ⚙️ 관리자 페이지
          </Link>
        </div>

        {/* Feature badges */}
        <div className="grid grid-cols-2 gap-3 pt-4">
          {[
            { icon: '📅', label: '날짜 투표' },
            { icon: '🎮', label: '4가지 게임' },
            { icon: '🏆', label: '당첨자 선정' },
            { icon: '🧾', label: 'PDF 영수증' },
          ].map(f => (
            <div key={f.label} className="card p-3 text-center">
              <div className="text-2xl">{f.icon}</div>
              <div className="text-sm mt-1" style={{ color: 'rgba(253,248,239,0.7)' }}>{f.label}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
