'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { Round, Member } from '@/types'
import Link from 'next/link'


function calcDday(dateStr: string | null): number | null {
  if (!dateStr) return null
  const today = new Date(); today.setHours(0,0,0,0)
  const target = new Date(dateStr); target.setHours(0,0,0,0)
  return Math.round((target.getTime() - today.getTime()) / 86400000)
}

function DdayBadge({ dateStr }: { dateStr: string | null }) {
  const diff = calcDday(dateStr)
  if (diff === null) return null
  const label = diff === 0 ? 'D-day' : diff < 0 ? `D+${Math.abs(diff)}` : `D-${diff}`
  const bg =
    diff === 0 ? 'rgba(76,175,80,0.25)' :
    diff < 0   ? 'rgba(120,120,120,0.18)' :
    diff <= 3  ? 'rgba(244,67,54,0.22)' :
    diff <= 7  ? 'rgba(255,152,0,0.22)' : 'rgba(74,158,255,0.18)'
  const color =
    diff === 0 ? '#4caf50' :
    diff < 0   ? 'rgba(253,248,239,0.3)' :
    diff <= 3  ? '#ff6b6b' :
    diff <= 7  ? '#ffb347' : '#4a9eff'
  return (
    <span style={{ fontSize: '11px', fontWeight: 700, padding: '2px 8px', borderRadius: '20px', background: bg, color, letterSpacing: '0.3px' }}>
      {label}
    </span>
  )
}

export default function AdminPage() {
  const [authed, setAuthed] = useState(false)
  const [pw, setPw] = useState('')
  const [rounds, setRounds] = useState<Round[]>([])
  const [loading, setLoading] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [selectedRound, setSelectedRound] = useState<Round | null>(null)
  const [members, setMembers] = useState<Member[]>([])
  const [dateSummary, setDateSummary] = useState<{date: string; count: number; names: string[]}[]>([])
  const [msg, setMsg] = useState('')

  const [form, setForm] = useState({
    month: '',
    amount: '',
    total_members: '',
    admin_password: '',
    notes: '',
  })

  const ADMIN_PW = process.env.NEXT_PUBLIC_ADMIN_PASSWORD || 'getdon2025'

  useEffect(() => {
    if (authed) fetchRounds()
  }, [authed])

  async function fetchRounds() {
    setLoading(true)
    const { data } = await supabase
      .from('rounds')
      .select('*')
      .order('round_number', { ascending: false })
    setRounds((data as Round[]) || [])
    setLoading(false)
  }

  async function fetchRoundDetail(round: Round) {
    setSelectedRound(round)
    const { data: mems } = await supabase
      .from('members')
      .select('*')
      .eq('round_id', round.id)
    setMembers((mems as Member[]) || [])

    const { data: votes } = await supabase
      .from('date_votes')
      .select('*')
      .eq('round_id', round.id)
    if (votes && mems) {
      const summary: Record<string, {count: number; names: string[]}> = {}
      votes.forEach((v: {date: string; member_id: string}) => {
        if (!summary[v.date]) summary[v.date] = { count: 0, names: [] }
        summary[v.date].count++
        const mem = (mems as Member[]).find(m => m.id === v.member_id)
        if (mem) summary[v.date].names.push(mem.name)
      })
      const sorted = Object.entries(summary)
        .map(([date, d]) => ({ date, ...d }))
        .sort((a, b) => b.count - a.count)
      setDateSummary(sorted)
    }
  }

  async function createRound() {
    if (!form.month || !form.amount || !form.total_members || !form.admin_password) {
      setMsg('모든 필드를 입력해주세요'); return
    }
    const { data: last } = await supabase
      .from('rounds').select('round_number').order('round_number', { ascending: false }).limit(1)
    const nextNum = last && last.length > 0 ? last[0].round_number + 1 : 1

    const { error } = await supabase.from('rounds').insert({
      round_number: nextNum,
      month: form.month,
      amount: parseInt(form.amount),
      total_members: parseInt(form.total_members),
      admin_password: form.admin_password,
      status: 'collecting_dates',
      notes: form.notes || null,
    })
    if (error) { setMsg('생성 실패: ' + error.message); return }
    setMsg('✅ 새 판 생성 완료!')
    setShowCreate(false)
    setForm({ month: '', amount: '', total_members: '', admin_password: '', notes: '' })
    fetchRounds()
  }

  async function confirmDate(date: string) {
    if (!selectedRound) return
    const { error } = await supabase
      .from('rounds')
      .update({ meeting_date: date, status: 'date_confirmed' })
      .eq('id', selectedRound.id)
    if (!error) {
      setMsg(`✅ ${date} 모임 날짜 확정!`)
      fetchRounds()
      fetchRoundDetail({ ...selectedRound, meeting_date: date, status: 'date_confirmed' })
    }
  }

  async function confirmPayment(memberId: string) {
    const { error } = await supabase
      .from('members')
      .update({ payment_confirmed: true })
      .eq('id', memberId)
    if (!error && selectedRound) fetchRoundDetail(selectedRound)
  }

  async function removeMember(memberId: string) {
    if (!confirm('정말 삭제할까요?')) return
    await supabase.from('members').delete().eq('id', memberId)
    if (selectedRound) fetchRoundDetail(selectedRound)
  }

  async function resetWinner() {
    if (!selectedRound || !confirm('당첨자를 초기화할까요?')) return
    await supabase.from('rounds').update({ winner_id: null, winner_name: null, game_type: null, status: 'date_confirmed' }).eq('id', selectedRound.id)
    await supabase.from('members').update({ has_won: false }).eq('round_id', selectedRound.id)
    fetchRounds()
    fetchRoundDetail(selectedRound)
    setMsg('✅ 당첨자 초기화 완료')
  }

  const statusLabel: Record<string, string> = {
    collecting_dates: '📅 날짜 수집 중',
    date_confirmed: '✅ 날짜 확정됨',
    game_played: '🎮 게임 완료',
    completed: '🏆 완료',
  }

  const statusColor: Record<string, string> = {
    collecting_dates: '#4a9eff',
    date_confirmed: '#4caf50',
    game_played: '#ff9800',
    completed: 'var(--gold)',
  }

  if (!authed) {
    return (
      <main className="min-h-screen flex items-center justify-center p-6">
        <div className="card card-glow p-8 w-full max-w-sm space-y-6">
          <div className="text-center">
            <div className="text-5xl">🔐</div>
            <h1 className="text-2xl font-bold mt-3" style={{ color: 'var(--gold)' }}>관리자 로그인</h1>
          </div>
          <input
            type="password"
            value={pw}
            onChange={e => setPw(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && (pw === ADMIN_PW ? setAuthed(true) : setMsg('비밀번호가 틀렸습니다'))}
            placeholder="관리자 비밀번호"
            className="w-full px-4 py-3 rounded-xl text-white"
            style={{ background: 'var(--navy-mid)', border: '1px solid rgba(201,168,76,0.3)' }}
          />
          {msg && <p className="text-red-400 text-sm text-center">{msg}</p>}
          <button
            onClick={() => pw === ADMIN_PW ? setAuthed(true) : setMsg('비밀번호가 틀렸습니다')}
            className="w-full py-3 rounded-xl font-bold btn-gold"
          >
            입장하기
          </button>
          <Link href="/" className="block text-center text-sm" style={{ color: 'rgba(253,248,239,0.4)' }}>← 홈으로</Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black" style={{ color: 'var(--gold)' }}>⚙️ 관리자</h1>
            <p className="text-sm mt-1" style={{ color: 'rgba(253,248,239,0.5)' }}>겟돈 계모임 관리 센터</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setShowCreate(true)} className="px-5 py-2 rounded-xl font-bold btn-gold text-sm">
              + 새 판 만들기
            </button>
            <Link href="/" className="px-4 py-2 rounded-xl text-sm" style={{ background: 'rgba(255,255,255,0.1)', color: 'var(--cream)' }}>홈</Link>
          </div>
        </div>

        {msg && (
          <div className="p-4 rounded-xl text-center font-medium" style={{ background: 'rgba(76,175,80,0.2)', color: '#4caf50', border: '1px solid rgba(76,175,80,0.3)' }}>
            {msg}
            <button onClick={() => setMsg('')} className="ml-3 opacity-50">✕</button>
          </div>
        )}

        {/* Create Round Modal */}
        {showCreate && (
          <div className="card card-glow p-6 space-y-4">
            <h2 className="text-xl font-bold" style={{ color: 'var(--gold)' }}>새 판 생성</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs mb-1 block" style={{ color: 'rgba(253,248,239,0.6)' }}>모임 월 (예: 2025년 1월)</label>
                <input value={form.month} onChange={e => setForm({...form, month: e.target.value})}
                  placeholder="2025년 1월" className="w-full px-3 py-2 rounded-lg text-white text-sm"
                  style={{ background: 'var(--navy-mid)', border: '1px solid rgba(201,168,76,0.3)' }} />
              </div>
              <div>
                <label className="text-xs mb-1 block" style={{ color: 'rgba(253,248,239,0.6)' }}>계금액 (원)</label>
                <input value={form.amount} onChange={e => setForm({...form, amount: e.target.value})}
                  placeholder="100000" type="number" className="w-full px-3 py-2 rounded-lg text-white text-sm"
                  style={{ background: 'var(--navy-mid)', border: '1px solid rgba(201,168,76,0.3)' }} />
              </div>
              <div>
                <label className="text-xs mb-1 block" style={{ color: 'rgba(253,248,239,0.6)' }}>총 인원</label>
                <input value={form.total_members} onChange={e => setForm({...form, total_members: e.target.value})}
                  placeholder="10" type="number" className="w-full px-3 py-2 rounded-lg text-white text-sm"
                  style={{ background: 'var(--navy-mid)', border: '1px solid rgba(201,168,76,0.3)' }} />
              </div>
              <div>
                <label className="text-xs mb-1 block" style={{ color: 'rgba(253,248,239,0.6)' }}>이번 판 비밀번호</label>
                <input value={form.admin_password} onChange={e => setForm({...form, admin_password: e.target.value})}
                  placeholder="참가자용 비밀번호" className="w-full px-3 py-2 rounded-lg text-white text-sm"
                  style={{ background: 'var(--navy-mid)', border: '1px solid rgba(201,168,76,0.3)' }} />
              </div>
              <div className="col-span-2">
                <label className="text-xs mb-1 block" style={{ color: 'rgba(253,248,239,0.6)' }}>메모 (선택)</label>
                <input value={form.notes} onChange={e => setForm({...form, notes: e.target.value})}
                  placeholder="특이사항 메모" className="w-full px-3 py-2 rounded-lg text-white text-sm"
                  style={{ background: 'var(--navy-mid)', border: '1px solid rgba(201,168,76,0.3)' }} />
              </div>
            </div>
            <div className="flex gap-3">
              <button onClick={createRound} className="flex-1 py-3 rounded-xl font-bold btn-gold">생성하기</button>
              <button onClick={() => setShowCreate(false)} className="px-6 py-3 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.1)', color: 'var(--cream)' }}>취소</button>
            </div>
          </div>
        )}

        {/* Rounds List + Detail */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Rounds List */}
          <div className="space-y-3">
            <h2 className="font-bold text-lg" style={{ color: 'var(--gold)' }}>판 목록</h2>
            {loading && <p style={{ color: 'rgba(253,248,239,0.4)' }}>불러오는 중...</p>}
            {rounds.map(r => (
              <button key={r.id} onClick={() => fetchRoundDetail(r)}
                className={`w-full text-left card p-4 transition-all ${selectedRound?.id === r.id ? 'ring-2' : ''}`}
                style={selectedRound?.id === r.id ? { borderColor: 'var(--gold)', outlineColor: 'var(--gold)' } : {}}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-lg">{r.round_number}판</span>
                    <span className="text-sm" style={{ color: 'rgba(253,248,239,0.6)' }}>{r.month}</span>
                    {r.meeting_date && <DdayBadge dateStr={r.meeting_date} />}
                  </div>
                  <span className="text-xs px-2 py-1 rounded-full" style={{ background: 'rgba(0,0,0,0.3)', color: statusColor[r.status] }}>
                    {statusLabel[r.status]}
                  </span>
                </div>
                <div className="mt-2 flex gap-4 text-sm" style={{ color: 'rgba(253,248,239,0.6)' }}>
                  <span>💰 {r.amount.toLocaleString()}원</span>
                  <span>👥 {r.total_members}명</span>
                  {r.meeting_date && <span>📅 {r.meeting_date}</span>}
                </div>
                {r.winner_name && (
                  <div className="mt-2 text-sm font-bold" style={{ color: 'var(--gold)' }}>
                    🏆 당첨: {r.winner_name}
                  </div>
                )}
              </button>
            ))}
            {rounds.length === 0 && !loading && (
              <div className="card p-8 text-center" style={{ color: 'rgba(253,248,239,0.4)' }}>
                아직 판이 없습니다<br />새 판을 만들어보세요!
              </div>
            )}
          </div>

          {/* Round Detail */}
          {selectedRound && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-lg" style={{ color: 'var(--gold)' }}>{selectedRound.round_number}판 상세</h2>
                <button onClick={() => setSelectedRound(null)} className="text-sm opacity-40">✕</button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-2">
                <div className="card p-3 text-center">
                  <div className="text-2xl font-black" style={{ color: 'var(--gold)' }}>{members.length}</div>
                  <div className="text-xs mt-1" style={{ color: 'rgba(253,248,239,0.5)' }}>참가인원</div>
                </div>
                <div className="card p-3 text-center">
                  <div className="text-2xl font-black" style={{ color: 'var(--gold)' }}>{members.filter(m => m.payment_confirmed).length}</div>
                  <div className="text-xs mt-1" style={{ color: 'rgba(253,248,239,0.5)' }}>납부확인</div>
                </div>
                <div className="card p-3 text-center">
                  <div className="text-2xl font-black" style={{ color: 'var(--gold)' }}>{selectedRound.total_members - members.length}</div>
                  <div className="text-xs mt-1" style={{ color: 'rgba(253,248,239,0.5)' }}>미참가</div>
                </div>
              </div>

              {/* Date votes */}
              {dateSummary.length > 0 && (
                <div className="card p-4 space-y-2">
                  <h3 className="font-bold text-sm" style={{ color: 'var(--gold)' }}>📊 날짜 투표 결과</h3>
                  {dateSummary.slice(0, 5).map(d => (
                    <div key={d.date} className="flex items-center gap-2">
                      <div className="flex-1">
                        <div className="flex items-center justify-between text-sm">
                          <span>{d.date}</span>
                          <span className="font-bold" style={{ color: 'var(--gold)' }}>{d.count}명</span>
                        </div>
                        <div className="h-1.5 rounded-full mt-1" style={{ background: 'rgba(255,255,255,0.1)' }}>
                          <div className="h-full rounded-full" style={{ 
                            width: `${(d.count / members.length) * 100}%`,
                            background: 'linear-gradient(90deg, var(--gold-dark), var(--gold))'
                          }} />
                        </div>
                        <div className="text-xs mt-1" style={{ color: 'rgba(253,248,239,0.4)' }}>{d.names.join(', ')}</div>
                      </div>
                      {selectedRound.status === 'collecting_dates' && (
                        <button onClick={() => confirmDate(d.date)} className="text-xs px-3 py-1 rounded-lg font-bold btn-gold whitespace-nowrap">
                          확정
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Action buttons */}
              <div className="flex gap-2 flex-wrap">
                {selectedRound.status === 'date_confirmed' && (
                  <Link href={`/game/${selectedRound.id}`} className="flex-1 py-2 rounded-xl text-sm font-bold btn-gold text-center">
                    🎮 게임 시작
                  </Link>
                )}
                {selectedRound.status === 'game_played' && (
                  <>
                    <Link href={`/receipt/${selectedRound.id}`} className="flex-1 py-2 rounded-xl text-sm font-bold btn-gold text-center">
                      🧾 영수증 보기
                    </Link>
                    <button onClick={resetWinner} className="px-4 py-2 rounded-xl text-sm"
                      style={{ background: 'rgba(255,68,68,0.2)', color: '#ff4444', border: '1px solid rgba(255,68,68,0.3)' }}>
                      초기화
                    </button>
                  </>
                )}
              </div>

              {/* Members list */}
              <div className="card p-4 space-y-2">
                <h3 className="font-bold text-sm mb-3" style={{ color: 'var(--gold)' }}>👥 참가자 명단</h3>
                {members.length === 0 && (
                  <p className="text-sm text-center py-4" style={{ color: 'rgba(253,248,239,0.4)' }}>아직 참가자가 없습니다</p>
                )}
                {members.map(m => (
                  <div key={m.id} className="flex items-center justify-between py-2 border-b" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
                    <div>
                      <span className="font-medium">{m.name}</span>
                      {m.has_won && <span className="ml-2 text-xs" style={{ color: 'var(--gold)' }}>🏆 당첨</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      {m.payment_confirmed 
                        ? <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(76,175,80,0.2)', color: '#4caf50' }}>납부완료</span>
                        : <button onClick={() => confirmPayment(m.id)} className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(255,152,0,0.2)', color: '#ff9800', border: '1px solid rgba(255,152,0,0.3)' }}>
                            납부확인
                          </button>
                      }
                      <button onClick={() => removeMember(m.id)} className="text-xs opacity-30 hover:opacity-70">✕</button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Round info */}
              <div className="card p-4">
                <h3 className="font-bold text-sm mb-2" style={{ color: 'var(--gold)' }}>📋 판 정보</h3>
                <div className="space-y-1 text-sm" style={{ color: 'rgba(253,248,239,0.6)' }}>
                  <div className="flex justify-between"><span>참가 링크:</span></div>
                  <div className="p-2 rounded-lg text-xs break-all" style={{ background: 'rgba(0,0,0,0.3)', color: 'var(--gold)' }}>
                    /join?round={selectedRound.id}
                  </div>
                  {selectedRound.notes && (
                    <div className="mt-2 pt-2 border-t" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
                      메모: {selectedRound.notes}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
