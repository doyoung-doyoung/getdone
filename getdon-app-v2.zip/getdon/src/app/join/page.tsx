'use client'

import { useState, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { Round, Member } from '@/types'
import Link from 'next/link'

// ── D-day 유틸 ──────────────────────────────────────────────────────
function calcDday(dateStr: string | null): number | null {
  if (!dateStr) return null
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const target = new Date(dateStr)
  target.setHours(0, 0, 0, 0)
  return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
}

function DdayBadge({ dateStr }: { dateStr: string | null }) {
  const diff = calcDday(dateStr)
  if (diff === null) return null

  let label: string
  let bg: string
  let color: string

  if (diff === 0) {
    label = 'D-day'
    bg = 'rgba(76,175,80,0.25)'
    color = '#4caf50'
  } else if (diff < 0) {
    label = `D+${Math.abs(diff)}`
    bg = 'rgba(120,120,120,0.2)'
    color = 'rgba(253,248,239,0.35)'
  } else if (diff <= 3) {
    label = `D-${diff}`
    bg = 'rgba(244,67,54,0.22)'
    color = '#ff6b6b'
  } else if (diff <= 7) {
    label = `D-${diff}`
    bg = 'rgba(255,152,0,0.22)'
    color = '#ffb347'
  } else {
    label = `D-${diff}`
    bg = 'rgba(74,158,255,0.18)'
    color = '#4a9eff'
  }

  return (
    <span style={{
      display: 'inline-block',
      fontSize: '12px',
      fontWeight: 700,
      padding: '3px 9px',
      borderRadius: '20px',
      background: bg,
      color,
      letterSpacing: '0.3px',
      lineHeight: 1.4,
    }}>
      {label}
    </span>
  )
}

function DdayText({ dateStr }: { dateStr: string | null }) {
  const diff = calcDday(dateStr)
  if (diff === null) return null
  if (diff === 0) return <span style={{ color: '#4caf50', fontWeight: 700 }}>오늘 모임이에요! 🎉</span>
  if (diff < 0) return <span style={{ color: 'rgba(253,248,239,0.35)' }}>모임이 {Math.abs(diff)}일 전에 있었어요</span>
  return (
    <span>
      모임까지 <strong style={{ color: diff <= 3 ? '#ff6b6b' : diff <= 7 ? '#ffb347' : '#4a9eff' }}>{diff}일</strong> 남았어요
    </span>
  )
}

// ── D-day 프로그레스 바 (30일 기준) ─────────────────────────────────
function DdayBar({ dateStr }: { dateStr: string | null }) {
  const diff = calcDday(dateStr)
  if (diff === null || diff < 0) return null
  const pct = Math.max(4, Math.round(((30 - Math.min(diff, 30)) / 30) * 100))
  const barColor =
    diff === 0 ? '#4caf50' :
    diff <= 3  ? '#ff6b6b' :
    diff <= 7  ? '#ffb347' : '#4a9eff'
  return (
    <div style={{ height: '3px', background: 'rgba(255,255,255,0.08)', borderRadius: '2px', marginTop: '10px' }}>
      <div style={{ height: '3px', borderRadius: '2px', width: `${pct}%`, background: barColor, transition: 'width 0.4s' }} />
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────

function JoinContent() {
  const searchParams = useSearchParams()
  const roundId = searchParams.get('round')

  const [step, setStep] = useState<'find' | 'register' | 'done'>('find')
  const [rounds, setRounds] = useState<Round[]>([])
  const [selectedRound, setSelectedRound] = useState<Round | null>(null)
  const [name, setName] = useState('')
  const [selectedDates, setSelectedDates] = useState<string[]>([])
  const [member, setMember] = useState<Member | null>(null)
  const [msg, setMsg] = useState('')
  const [loading, setLoading] = useState(false)
  const [calendarDates, setCalendarDates] = useState<{value: string; isWeekend: boolean}[]>([])

  useEffect(() => {
    if (roundId) fetchRoundById(roundId)
    else fetchActiveRounds()
  }, [roundId])

  async function fetchActiveRounds() {
    const { data } = await supabase
      .from('rounds')
      .select('*')
      .in('status', ['collecting_dates', 'date_confirmed'])
      .order('round_number', { ascending: false })
    setRounds((data as Round[]) || [])
    setStep('find')
  }

  async function fetchRoundById(id: string) {
    const { data } = await supabase.from('rounds').select('*').eq('id', id).single()
    if (data) selectRound(data as Round)
  }

  function selectRound(round: Round) {
    setSelectedRound(round)
    const now = new Date()
    const year = now.getFullYear()
    const monthNum = now.getMonth() + 1
    const daysInMonth = new Date(year, monthNum, 0).getDate()
    const dates = []
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, monthNum - 1, d)
      const dayOfWeek = date.getDay()
      const dateStr = `${year}-${String(monthNum).padStart(2,'0')}-${String(d).padStart(2,'0')}`
      dates.push({ value: dateStr, isWeekend: dayOfWeek === 0 || dayOfWeek === 6 })
    }
    setCalendarDates(dates)
    setStep('register')
  }

  function toggleDate(date: string) {
    setSelectedDates(prev =>
      prev.includes(date) ? prev.filter(d => d !== date) : [...prev, date]
    )
  }

  async function submitRegistration() {
    if (!selectedRound || !name.trim()) { setMsg('이름을 입력해주세요'); return }
    if (selectedRound.status === 'collecting_dates' && selectedDates.length === 0) {
      setMsg('가능한 날짜를 최소 1개 이상 선택해주세요'); return
    }
    setLoading(true)

    const { data: existing } = await supabase
      .from('members').select('id').eq('round_id', selectedRound.id).eq('name', name.trim())
    if (existing && existing.length > 0) {
      setMsg('이미 등록된 이름입니다. 다른 이름을 사용해주세요')
      setLoading(false); return
    }

    const { data: mem, error } = await supabase
      .from('members')
      .insert({ round_id: selectedRound.id, name: name.trim(), available_dates: selectedDates, has_won: false, payment_confirmed: false })
      .select().single()

    if (error) { setMsg('등록 실패: ' + error.message); setLoading(false); return }

    if (selectedDates.length > 0) {
      await supabase.from('date_votes').insert(
        selectedDates.map(d => ({ round_id: selectedRound.id, member_id: mem.id, date: d }))
      )
    }

    setMember(mem as Member)
    setStep('done')
    setLoading(false)
  }

  const dayLabels = ['일', '월', '화', '수', '목', '금', '토']

  return (
    <main className="min-h-screen p-4 md:p-8">
      <div className="max-w-lg mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-1">
          <Link href="/" className="text-2xl font-black" style={{ color: 'var(--gold)' }}>💰 겟돈</Link>
          <p className="text-sm" style={{ color: 'rgba(253,248,239,0.5)' }}>계모임 참가하기</p>
        </div>

        {msg && (
          <div className="p-3 rounded-xl text-sm text-center" style={{ background: 'rgba(255,68,68,0.2)', color: '#ff6b6b' }}>
            {msg} <button onClick={() => setMsg('')} className="ml-2 opacity-50">✕</button>
          </div>
        )}

        {/* ── Step: 판 선택 ─────────────────────────────── */}
        {step === 'find' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold" style={{ color: 'var(--gold)' }}>참가할 판 선택</h2>
            {rounds.length === 0 && (
              <div className="card p-8 text-center" style={{ color: 'rgba(253,248,239,0.4)' }}>
                현재 참가 가능한 판이 없습니다
              </div>
            )}
            {rounds.map(r => (
              <button key={r.id} onClick={() => selectRound(r)}
                className="w-full text-left card p-5 hover:border-yellow-500 transition-all">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black" style={{ color: 'var(--gold)' }}>{r.round_number}판</span>
                    <span className="font-medium">{r.month}</span>
                  </div>
                  {/* D-day 배지 — 날짜 확정된 판만 표시 */}
                  {r.meeting_date && <DdayBadge dateStr={r.meeting_date} />}
                </div>

                <div className="mt-2 flex gap-4 text-sm" style={{ color: 'rgba(253,248,239,0.6)' }}>
                  <span>💰 {r.amount.toLocaleString()}원</span>
                  <span>👥 {r.total_members}명</span>
                </div>

                {r.meeting_date && (
                  <>
                    <div className="mt-2 text-xs" style={{ color: 'rgba(253,248,239,0.5)' }}>
                      📅 {r.meeting_date} &nbsp;·&nbsp; <DdayText dateStr={r.meeting_date} />
                    </div>
                    <DdayBar dateStr={r.meeting_date} />
                  </>
                )}
                {!r.meeting_date && (
                  <div className="mt-2 text-xs" style={{ color: 'rgba(253,248,239,0.35)' }}>
                    📅 날짜 투표 중
                  </div>
                )}
              </button>
            ))}
          </div>
        )}

        {/* ── Step: 등록 ────────────────────────────────── */}
        {step === 'register' && selectedRound && (
          <div className="space-y-6">
            {/* 판 정보 카드 — D-day 포함 */}
            <div className="card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-black" style={{ color: 'var(--gold)' }}>{selectedRound.round_number}판</span>
                  <div>
                    <div className="font-bold">{selectedRound.month}</div>
                    <div className="text-sm mt-0.5" style={{ color: 'rgba(253,248,239,0.5)' }}>
                      💰 {selectedRound.amount.toLocaleString()}원 · 👥 {selectedRound.total_members}명
                    </div>
                  </div>
                </div>
                {selectedRound.meeting_date && <DdayBadge dateStr={selectedRound.meeting_date} />}
              </div>

              {selectedRound.meeting_date && (
                <>
                  <div className="mt-3 text-sm" style={{ color: 'rgba(253,248,239,0.55)' }}>
                    📅 {selectedRound.meeting_date} &nbsp;·&nbsp; <DdayText dateStr={selectedRound.meeting_date} />
                  </div>
                  <DdayBar dateStr={selectedRound.meeting_date} />
                </>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold" style={{ color: 'var(--gold)' }}>이름 입력</label>
              <input
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="이름을 입력하세요"
                className="w-full px-4 py-3 rounded-xl text-white text-lg"
                style={{ background: 'var(--navy-light)', border: '1px solid rgba(201,168,76,0.3)' }}
              />
            </div>

            {selectedRound.status === 'collecting_dates' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-bold" style={{ color: 'var(--gold)' }}>가능한 날짜 선택</label>
                  <span className="text-xs" style={{ color: 'rgba(253,248,239,0.4)' }}>{selectedDates.length}개 선택됨</span>
                </div>
                <div className="card p-4">
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {dayLabels.map(d => (
                      <div key={d} className="text-center text-xs font-bold py-1"
                        style={{ color: d === '일' ? '#ff6b6b' : d === '토' ? '#4a9eff' : 'rgba(253,248,239,0.4)' }}>
                        {d}
                      </div>
                    ))}
                  </div>
                  {(() => {
                    if (calendarDates.length === 0) return null
                    const firstDay = new Date(calendarDates[0].value).getDay()
                    const cells = []
                    for (let i = 0; i < firstDay; i++) cells.push(<div key={`e${i}`} />)
                    calendarDates.forEach(d => {
                      const day = new Date(d.value).getDay()
                      const dayNum = parseInt(d.value.split('-')[2])
                      const isSelected = selectedDates.includes(d.value)
                      cells.push(
                        <button key={d.value} onClick={() => toggleDate(d.value)}
                          className="aspect-square rounded-lg text-sm font-medium transition-all flex items-center justify-center"
                          style={{
                            background: isSelected ? 'linear-gradient(135deg, var(--gold-light), var(--gold))' : 'rgba(255,255,255,0.05)',
                            color: isSelected ? 'var(--navy)' : day === 0 ? '#ff6b6b' : day === 6 ? '#4a9eff' : 'var(--cream)',
                            fontWeight: isSelected ? 700 : 400,
                          }}
                        >
                          {dayNum}
                        </button>
                      )
                    })
                    return <div className="grid grid-cols-7 gap-1">{cells}</div>
                  })()}
                </div>
              </div>
            )}

            {selectedRound.status === 'date_confirmed' && (
              <div className="card p-4 text-center">
                <div className="text-2xl">📅</div>
                <div className="font-bold mt-2" style={{ color: '#4caf50' }}>날짜가 확정되었습니다</div>
                <div className="text-lg font-black mt-1" style={{ color: 'var(--gold)' }}>{selectedRound.meeting_date}</div>
                <div className="mt-1 text-sm" style={{ color: 'rgba(253,248,239,0.5)' }}>
                  <DdayText dateStr={selectedRound.meeting_date} />
                </div>
              </div>
            )}

            <button onClick={submitRegistration} disabled={loading} className="w-full py-4 rounded-xl font-bold text-lg btn-gold">
              {loading ? '등록 중...' : '✅ 참가 등록하기'}
            </button>
          </div>
        )}

        {/* ── Step: 완료 ────────────────────────────────── */}
        {step === 'done' && member && selectedRound && (
          <div className="space-y-6 text-center">
            <div className="text-6xl animate-bounce-in">🎉</div>
            <div className="card card-glow p-8 space-y-4">
              <h2 className="text-2xl font-black" style={{ color: 'var(--gold)' }}>참가 완료!</h2>
              <p className="text-lg font-bold">{member.name}님 등록되었습니다</p>

              {/* D-day 강조 블록 */}
              {selectedRound.meeting_date && (
                <div className="py-3 px-4 rounded-xl" style={{ background: 'rgba(0,0,0,0.25)' }}>
                  <div className="flex items-center justify-center gap-2 mb-1">
                    <span className="text-sm" style={{ color: 'rgba(253,248,239,0.5)' }}>모임 날짜</span>
                    <DdayBadge dateStr={selectedRound.meeting_date} />
                  </div>
                  <div className="text-xl font-black" style={{ color: 'var(--gold)' }}>
                    📅 {selectedRound.meeting_date}
                  </div>
                  <div className="text-sm mt-1" style={{ color: 'rgba(253,248,239,0.5)' }}>
                    <DdayText dateStr={selectedRound.meeting_date} />
                  </div>
                  <DdayBar dateStr={selectedRound.meeting_date} />
                </div>
              )}

              <div className="space-y-1 text-sm" style={{ color: 'rgba(253,248,239,0.6)' }}>
                {member.available_dates.length > 0 && (
                  <p>📅 가능 날짜: {member.available_dates.length}개 선택</p>
                )}
                <p>💰 {selectedRound.amount.toLocaleString()}원 준비해주세요</p>
                {selectedRound.status === 'collecting_dates' && (
                  <p className="pt-1 text-xs">날짜가 확정되면 알려드릴게요!</p>
                )}
              </div>
            </div>
            <Link href="/" className="block py-3 rounded-xl" style={{ color: 'rgba(253,248,239,0.5)' }}>홈으로 돌아가기</Link>
          </div>
        )}
      </div>
    </main>
  )
}

export default function JoinPage() {
  return (
    <Suspense>
      <JoinContent />
    </Suspense>
  )
}
