# 💰 겟돈 - 계모임 관리 앱

계모임(계)을 스마트하게 관리하는 웹 앱입니다.

## 기능

### 참가자
- 이름 등록 및 가능 날짜 선택 (캘린더 UI)
- 실시간 참가 현황 확인

### 관리자
- 새 판 생성 (금액, 인원, 비밀번호 설정)
- 날짜 투표 집계 및 확정
- 납부 확인 처리
- 4가지 게임으로 당첨자 선정
- 당첨자 PDF 영수증 발행

### 게임
- 룰렛 뽑기 / 버튼 누르기 / 주사위 굴리기 / 사다리 타기

---

## 배포 방법

### 1. Supabase 설정
1. supabase.com 에서 새 프로젝트 생성
2. SQL Editor에서 `supabase-schema.sql` 실행
3. Settings > API 에서 URL과 anon key 복사

### 2. Vercel 배포
```bash
git init && git add . && git commit -m "init"
git push -u origin main
```
Vercel에서 GitHub 연결 후 환경변수 설정:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY  
- NEXT_PUBLIC_ADMIN_PASSWORD

### 3. 로컬 개발
```bash
cp .env.example .env.local  # 키 입력
npm install && npm run dev
```

## Vercel 무료 플랜
- 배포: 무제한
- 대역폭: 100GB/월
- 이 앱은 정적 페이지 위주라 완전 무료 운영 가능

## 기술 스택
- Next.js 14 + TypeScript
- Supabase (PostgreSQL)
- Tailwind CSS
- jsPDF + html2canvas (PDF 영수증)
- Vercel (무료 배포)
