-- 겟돈 (계모임 앱) Supabase 스키마
-- Supabase SQL Editor에서 실행하세요

-- 1. rounds 테이블 (계모임 판)
CREATE TABLE IF NOT EXISTS rounds (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  round_number INTEGER NOT NULL,
  month TEXT NOT NULL,
  amount INTEGER NOT NULL DEFAULT 100000,
  total_members INTEGER NOT NULL DEFAULT 10,
  status TEXT NOT NULL DEFAULT 'collecting_dates'
    CHECK (status IN ('collecting_dates', 'date_confirmed', 'game_played', 'completed')),
  meeting_date TEXT,
  winner_id UUID,
  winner_name TEXT,
  game_type TEXT CHECK (game_type IN ('draw', 'button', 'dice', 'ladder')),
  admin_password TEXT NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. members 테이블 (참가자)
CREATE TABLE IF NOT EXISTS members (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID NOT NULL REFERENCES rounds(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  available_dates TEXT[] DEFAULT '{}',
  has_won BOOLEAN DEFAULT FALSE,
  payment_confirmed BOOLEAN DEFAULT FALSE,
  joined_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. date_votes 테이블 (날짜 투표)
CREATE TABLE IF NOT EXISTS date_votes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  round_id UUID NOT NULL REFERENCES rounds(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  UNIQUE(member_id, date)
);

-- RLS (Row Level Security) - 공개 읽기/쓰기 허용 (무료 앱용)
ALTER TABLE rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE date_votes ENABLE ROW LEVEL SECURITY;

-- 누구나 읽기 가능
CREATE POLICY "rounds_read" ON rounds FOR SELECT USING (true);
CREATE POLICY "members_read" ON members FOR SELECT USING (true);
CREATE POLICY "date_votes_read" ON date_votes FOR SELECT USING (true);

-- 누구나 쓰기 가능 (서비스 특성상 오픈)
CREATE POLICY "rounds_insert" ON rounds FOR INSERT WITH CHECK (true);
CREATE POLICY "rounds_update" ON rounds FOR UPDATE USING (true);
CREATE POLICY "rounds_delete" ON rounds FOR DELETE USING (true);

CREATE POLICY "members_insert" ON members FOR INSERT WITH CHECK (true);
CREATE POLICY "members_update" ON members FOR UPDATE USING (true);
CREATE POLICY "members_delete" ON members FOR DELETE USING (true);

CREATE POLICY "date_votes_insert" ON date_votes FOR INSERT WITH CHECK (true);
CREATE POLICY "date_votes_delete" ON date_votes FOR DELETE USING (true);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_members_round_id ON members(round_id);
CREATE INDEX IF NOT EXISTS idx_date_votes_round_id ON date_votes(round_id);
CREATE INDEX IF NOT EXISTS idx_date_votes_member_id ON date_votes(member_id);
